# General FAQs_cn

## 请问我怎么样使用pull request？
使用pull request非常简单。
1.	将YDLidar-SDk Repository fork到你自己的Github中。
2.	在你的Repository中建立一个开发者 Branch。
3.	在开发者Branch中commit你做的任何的改变
4.	在你的github网页中使用pull request	

**参考更多的FAQs**
